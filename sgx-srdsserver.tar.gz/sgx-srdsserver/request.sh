wget http://msstream.net:8023/api/description/ANxeFQQ89Vg/1?order=111111000000&q0=412194&q1=6111175
wget http://msstream.net:8023/api/description/ANxeFQQ89Vg/6111175/init
http://localhost:8080/api/description/ANxeFQQ89Vg/1?order=111111000000&q0=412194&q1=6111175
http://localhost:8080/api/description/ANxeFQQ89Vg/6111175/init
curl -XGET 147.210.128.146:8082/api/description/-VTTEQN_Q1o/413240/init -H "X-Forwarded-Host: 147.210.128.140:8081"

