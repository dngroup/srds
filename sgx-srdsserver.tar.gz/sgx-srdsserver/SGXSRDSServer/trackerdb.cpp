//
// Created by mlacaud on 04/03/18.
//

#include "trackerdb.h"

TrackerDB::TrackerDB() {};
TrackerDB::~TrackerDB() {};

void TrackerDB::createKey(std::string videoId) {}
void TrackerDB::addAddrByVideoId(std::string videoId) {}
void TrackerDB::getPeersForId(std::string videoId) {}
void TrackerDB::deletePeerForId(std::string videoId, std::string peer) {}

